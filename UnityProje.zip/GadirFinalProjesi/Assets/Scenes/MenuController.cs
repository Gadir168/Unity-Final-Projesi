using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    // Mütləq 'public' olmalıdır ki, siyahıda görünsün
    public void Oyna()
    {
        SceneManager.LoadScene("SampleScene"); 
    }

    public void Cixis()
    {
        Debug.Log("Oyundan çıxıldı!");
        Application.Quit();
        
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #endif
    }
}