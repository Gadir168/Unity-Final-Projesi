using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 7f; // Oyunçunun hərəkət sürəti

    void Update()
    {
        // Klaviaturadan A-D və ya sağ-sol oxlarını oxuyur
        float h = Input.GetAxis("Horizontal");
        
        // Yeni mövqeyi hesablayır
        Vector2 pos = transform.position;
        pos.x += h * speed * Time.deltaTime;
        
        // Ekrandan kənara çıxmaması üçün sərhəd (təxmini -8 və 8 arası)
        pos.x = Mathf.Clamp(pos.x, -8f, 8f);
        
        transform.position = pos;
    }
}