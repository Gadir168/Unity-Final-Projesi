using UnityEngine;

public class Shooting : MonoBehaviour
{
    public GameObject bulletPrefab; // Atacağımız güllə forması

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) // Space basanda
        {
            Shoot();
        }
    }

    void Shoot()
{
    // transform.position - bu kod skriptin olduğu obyektin (yəni Playerin) yerini götürür
    Instantiate(bulletPrefab, transform.position, Quaternion.identity);
}
}