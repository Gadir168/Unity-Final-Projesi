using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager instance;

    public TextMeshProUGUI scoreText;
    // BAX BURA: Artıq healthText yoxdur, GameObject massivi var
    public GameObject[] healthBalls; 
    public GameObject gameOverPanel;

    private int score = 0;
    public int health = 3;

    void Awake()
    {
        if (instance == null) { instance = this; }
    }

    void Start()
    {
        UpdateUI();
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        Time.timeScale = 1;
    }

    public void ChangeScore(int amount)
    {
        score += amount;
        UpdateUI();
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        UpdateUI();
        if (health <= 0) { GameOver(); }
    }

    void UpdateUI()
    {
        if (scoreText != null) scoreText.text = "Puan: " + score;

        // Topları gizlədib-açan hissə
        if (healthBalls != null)
        {
            for (int i = 0; i < healthBalls.Length; i++)
            {
                if (i < health)
                    healthBalls[i].SetActive(true);
                else
                    healthBalls[i].SetActive(false);
            }
        }
    }

    void GameOver()
    {
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
        Time.timeScale = 0;
    }

    public void RestartGame() { Time.timeScale = 1; SceneManager.LoadScene(SceneManager.GetActiveScene().name); }
    public void ExitGame()
{
    // Oyun donubsa (Time.timeScale = 0), onu normala qaytarırıq
    Time.timeScale = 1; 
    
    // Menyu səhnəsini yükləyirik. 
    // "MainMenu" yerinə sənin menyu səhnənin dəqiq adı nədirsə onu yaz.
    SceneManager.LoadScene("MainMenu"); 
}
}