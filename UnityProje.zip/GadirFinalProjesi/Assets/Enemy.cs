using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 2f;
    public int scoreValue = 10;
    public int damageValue = 1;

    void Update()
    {
        // Aşağı hərəkət
        transform.Translate(Vector2.down * speed * Time.deltaTime);

        // Ekranın aşağısından çıxanda can aparsın
        // Əgər -6 çox uzaqdırsa, bunu -5f et
        if (transform.position.y < -5.5f)
        {
            if (ScoreManager.instance != null)
            {
                ScoreManager.instance.TakeDamage(damageValue);
            }
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Güllə dəyəndə xal versin
        if (other.CompareTag("Bullet"))
        {
            if (ScoreManager.instance != null)
            {
                ScoreManager.instance.ChangeScore(scoreValue);
            }
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
    }
}