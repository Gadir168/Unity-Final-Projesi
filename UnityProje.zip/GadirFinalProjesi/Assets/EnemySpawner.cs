using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject[] enemyPrefabs; // Qırmızı və Qara prefablar bura gələcək
    public float spawnInterval = 1.5f; // Hər 1.5 saniyədən bir düşmən gəlsin

    void Start()
    {
        // Oyuna başlayan kimi hər intervaldan bir SpawnEnemy funksiyasını çağırır
        InvokeRepeating("SpawnEnemy", 1.0f, spawnInterval);
    }

 void SpawnEnemy()
{
    float randomX = Random.Range(-7f, 7f);
    Vector2 spawnPos = new Vector2(randomX, 6f);

    int chance = Random.Range(0, 100);

    if (chance < 70) // %70 ehtimalla Qırmızı
    {
        Instantiate(enemyPrefabs[0], spawnPos, Quaternion.identity);
    }
    else if (chance < 95) // %25 ehtimalla Qara
    {
        Instantiate(enemyPrefabs[1], spawnPos, Quaternion.identity);
    }
    else // %5 ehtimalla BOMBA (çox nadir və təhlükəli)
    {
        Instantiate(enemyPrefabs[2], spawnPos, Quaternion.identity);
    }
}
}